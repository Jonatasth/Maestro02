package com.flexxo.nomenclatura;

/**
 * Classes ou m�todos, podem come�ar com um underscore (_), uma letra ou um cifr�o ($).
 * Depois do primeiro caracter os identificadores podem incluir tamb�m d�gitos, al�m de
 * poderem ter qualquer tamanho. Exemplo de nomes permitidos:
 * 
 * Conven��es de c�digo
 * 
 * Classes e Interfaces: primeira letra deve ser mai�scula e a primeira
 * letra de cada palavra subseq�ente dever� ser mai�scula (padr�o
 * camelCase). Para classes os nomes geralmente devem ser
 * substantivos. Para interfaces, adjetivos.
 * Exemplo de nomes de classe: Pedido, Estoque.
 * Exemplo de interface: Executavel, Serializavel.
 * 
 * M�todos: primeira letra deve ser min�scula e depois a regra
 * camelCase normal. Os m�todos normalmente devem ser pares de
 * verbossubstantivo. Exemplo: buscarRegistros, executaProcesso,
 * somaValores.
 * 
 * Vari�veis: idem ao padr�o de nomenclatura do m�todo. Usar
 * nomes curtos e significativos.
 * Exemplo: larguraDoBotao, contadorDeRegistros...
 * 
 * Constantes: Constantes s�o criadas com os modificadores
 * static final. Elas devem ser nomeadas usando-se letra mai�scula com
 * underscore entre as palavras.
 * Exemplo: ALTURA_MINIMA.
 */
// Atribui��o de classes e interfaces. Primeira letra caixa alta
public class Variaveis {
	
	private int						$var;
	
	private int						_var;
	
	private int						var;
	
	private int						var123;
	
	// private int 123var ?;
	//
	// private int var_;
	//
	// private int var#;
	//
	// private int #var;
	//
	// private int $_var;
	//
	// private int $$var;
	//
	// private int __var;
	//
	// private int _$var123;
	//
	// private int _%var;
	
	// Seguir conven��o java que adota padr�o camelCase
	private int						minhaVariavel;
	
	// Java � case sensitive logo isto funciona MAS N�O � LEGAL (NEM UM POUCO)
	private int						MinhaVariavel;
	
	// atribui��o de constantes (VALORES QUE NUNCA MUDAM)
	private static final Integer	VALOR_CONSTANTE	= 1;
	
	// preferencialmente usar um verbo
	private void somarValores() {
		
	}
	
}
