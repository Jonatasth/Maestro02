package com.flexxo;

public class AtributosEMetodosTest {
	
	public static void main(String[] args) {
		
		// Instancia a classe e chama o m�todo somar
		AtributosEMetodos a = new AtributosEMetodos();
		a.somar();
		a.efetuarNovaSoma();
		a.efetuarSomaLocalEClasse();
	}
}
