package com.flexxo;

public class ModificadoresBean {
	
	protected Integer	varTres;
	
	// DEFAULT
	Integer				varQuatro;
}
