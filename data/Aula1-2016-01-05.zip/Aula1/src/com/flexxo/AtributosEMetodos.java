package com.flexxo;

// N�o solicitou nenhum import ao utilizar a classe Integer pois todas classes estendem de Object
public class AtributosEMetodos {
	
	// Declara vari�vel inteira tipo Objeto
	private Integer	valorUm;
	
	// Declara vari�vel inteira tipo primitivo
	private int		valorDois;
	
	/**
	 * Efetua a soma entre variaveis de classe
	 */
	// cria um m�todo publico somar para efetuar a soma dos atributos de classe
	public void somar() {
		
		// Atribui valor 1
		valorUm = 1;
		
		// Atribui valor 2
		valorDois = 2;
		
		// Efetua a soma e exibe no console
		System.out.println("somar: " + (valorUm + valorDois));
	}
	
	/**
	 * Efetua a soma entre variaveis locais
	 */
	public void efetuarNovaSoma() {
		
		// Declara duas vari�veis locais apenas de m�todo
		Integer valorUm = 2;
		Integer valorDois = 5;
		
		// Declara uma vari�vel que recebe o resultado do c�lculo efetuado
		Integer valorSoma = valorUm + valorDois;
		
		// Imprime na tela a resposta
		System.out.println("efetuarNovaSoma: " + valorSoma);
	}
	
	/**
	 * Efetua a soma entre uma vari�vel do m�todo local com um atributo da classe (vari�vel de instancia)
	 */
	public void efetuarSomaLocalEClasse() {
		
		// Declara uma vari�vel local de m�todo
		Integer valorDois = 3;
		
		// Soma vari�vel do m�todo com atributo da classe para isso o this � necess�rio para indicar que � a vari�vel da
		// classe e n�o do m�todo
		System.out.println("efetuarSomaLocalEClasse: " + (valorDois + this.valorDois));
	}
}
