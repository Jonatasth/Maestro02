package com.flexxo.modificadores;

import com.flexxo.ModificadoresBean;

public class ReferenteAoAcessoMain {
	
	public static void main(String[] args) {
		
		ReferenteAoAcesso r = new ReferenteAoAcesso();
		// � poss�vel acessar pois � publica
		r.varUm = 1;
		
		// permite acessar pois � do mesmo pacote desta classe main
		r.varTres = 3;
		
		// permite acessar pois � do mesmo pacote
		r.varQuatro = 4;
		
		// var dois ? n�o pode acessar de nenhum lugar que nao seja dentro da pr�pria classe ReferenteAoAcesso
		
		// ####### teste com outra classe
		
		ModificadoresBean b = new ModificadoresBean();
		// b.set...???
		// Nennhum atributo visivel pois nao pertecem ao mesmo pacote
		
	}
}
