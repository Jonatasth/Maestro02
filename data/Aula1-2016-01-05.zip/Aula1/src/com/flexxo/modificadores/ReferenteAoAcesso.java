package com.flexxo.modificadores;

import com.flexxo.ModificadoresBean;

/**
 * Classe para exemplifica��o de modificadores Java referente ao acesso. S�o eles:
 * 
 * - Public: Qualquer classe poder� acessar um m�todo ou vari�vel declarado com
 * este modificador.
 * 
 * - Protected: Apenas classes do mesmo pacote e classes filhas (independente do
 * pacote) podem acessar um membro com esta visibilidade.
 * 
 * - Private: Membros declarados com este modificador s� podem ser utilizados dentro
 * da pr�pria classe.
 * 
 * - Default: Apenas classes do mesmo podem acessar um membro com esta
 * visibilidade.
 * 
 * @author Tiago Colleoni Zaro
 * @since 28/12/2015
 * */
public class ReferenteAoAcesso extends ModificadoresBean {
	
	public Integer		varUm;
	
	private Integer		varDois;
	
	protected Integer	varTres;
	
	Integer				varQuatro;
	
	private void modificadoresProtected() {
		
		super.varTres = 5;
		// var quatro nao temos acesso pois s� pelo mesmo pacote
	}
}
