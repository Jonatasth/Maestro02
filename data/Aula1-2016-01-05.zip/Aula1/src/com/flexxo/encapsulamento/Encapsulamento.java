package com.flexxo.encapsulamento;

/**
 * Classe para demonstrar utiliza��o do encapsulamento
 * 
 * @author Tiago Colleoni Zaro
 */
public class Encapsulamento {
	
	private String	codPessoa;
	
	private String	nomePessoa;
	
	/**
	 * @return the codPessoa
	 */
	public String getCodPessoa() {
		return codPessoa;
	}
	
	/**
	 * @param codPessoa
	 *            the codPessoa to set
	 */
	public void setCodPessoa(String codPessoa) {
		this.codPessoa = codPessoa;
		// this.codPessoa = "0" + this.codPessoa;
	}
	
	/**
	 * @return the nomePessoa
	 */
	public String getNomePessoa() {
		return nomePessoa;
	}
	
	/**
	 * @param nomePessoa
	 *            the nomePessoa to set
	 */
	public void setNomePessoa(String nomePessoa) {
		this.nomePessoa = nomePessoa;
	}
	
	public void apresentarPessoa() {
		System.out.println("Ol� meu nome �: " + nomePessoa);
		System.out.println("Meu c�digo no sistema: " + codPessoa);
	}
}
