package com.flexxo.encapsulamento;

public class EncaspulamentoMain {
	
	public static void main(String[] args) {
		
		Encapsulamento e = new Encapsulamento();
		
		e.setCodPessoa("1");
		e.setNomePessoa("Pessoa F�sica");
		e.apresentarPessoa();
		
		System.out.println("C�digo Pessoa:" + e.getCodPessoa());
	}
}
