// Caminho do pacote
package com.flexxo;

// imports de bibliotecas e classes necess�rias

// nome da classe - deve ser obrigatoriamente o mesmo do nome do arquivo .java
public class PrimeiraClasse {
	
	// M�todo main
	public static void main(String[] args) {
		
		// Imprime no console
		System.out.println("Curso Android 2016");
	}
}
